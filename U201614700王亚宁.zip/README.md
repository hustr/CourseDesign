# CourseDesign

## 数据结构课程设计

代码分为4层：

1. [最底层](https://github.com/hustr/CourseDesign/blob/master/AVLTree.hpp)，AVLTree实现层


2. [逻辑层](https://github.com/hustr/CourseDesign/blob/master/Set.hpp)， Set实现层


3. [应用层](https://github.com/hustr/CourseDesign/blob/master/Person.hpp)，Perosn实现层


4. [操作层](https://github.com/hustr/CourseDesign/blob/master/Operations.hpp)，各种主要操作的实现